package fr.esisar.calculatrice;

public class Calculatrice {

	
	public Integer ajouter(Integer operande1, Integer operande2){
		//System.out.println(operande1+operande2);
		return operande1+operande2;

	}
	
	public Integer soustraire(Integer operande1, Integer operande2){
		System.out.println(operande1-operande2);
		return operande1-operande2;

	}
	
	public Integer multiplier(Integer operande1, Integer operande2){
		//System.out.println(operande1*operande2);
		return operande1*operande2;

	}
	
	public Integer diviser(Integer operande1, Integer operande2){
		//System.out.println(operande1/operande2);
		return operande1/operande2;
	}
	
	
}
